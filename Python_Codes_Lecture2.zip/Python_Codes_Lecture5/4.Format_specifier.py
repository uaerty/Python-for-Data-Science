#It defines type of data to be printed on standard output
print ('To print a float: %f' % 1234.567890)
print ('To print a float with two decimals only: %.2f' % 1234.567890)
print ('To print a integer: %d' % 4)
print ("we are at %d%%" % 100)
print ('Your host is: %s' % 'earth')
print ('Host: %s\tPort: %d' % ('mars', 80))