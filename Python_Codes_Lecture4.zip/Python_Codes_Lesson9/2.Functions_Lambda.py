# A Python program to run Lambda Function using the normally defined function
def cube(y):
	return y*y*y
# using the Lambda function
lambda_cube = lambda y: y**y
data = [[4, 9, 16], [25, 36, 49], [64, 81, 100]]
print("Data: ",data)
print("Second Index",data[0][2])
print("Third Index",data[2][0])
print("Print Cube output using Normal Function: ",cube(4))

# using the lambda function
print("Print output using Lambda Function: ",lambda_cube(4))

company = ["ericsson","lotus","google"]
dreamcompany = company
dreamcompany [1] = "infy"
capcompany =[] 
for a in dreamcompany:
    b = a.upper();capcompany.append(b)
print("Dream Company: ",dreamcompany)  	
print("Cap Company: ",capcompany)  					
# Print List of people above 18 yrs
ages = [13, 90, 17, 59, 21, 60, 5]
newages = []
for comp in ages:
    	if(comp<30):
    		newages.append(comp)
	
print("newages Company: ",newages)
adults = list(filter(lambda age: age>18, ages))
print("Print List of people above 18 yrs: ",adults)

# Python code to illustrate map() with lambda() to get double of a list.
li = [5, 7, 22, 97, 54, 62, 77, 23, 73, 61]
threetime = [x for x in li if x < 30]
print(threetime)
final_list = list(map(lambda x: x*2, li))
print("lambda function to double values of a list: ",final_list)

# using the lambda function for loop and List Comprehension
tables = [lambda x=x: x*10 for x in range(1, 4)]
for table in tables:
	print("lambda function for List Comprehension: ",table())


