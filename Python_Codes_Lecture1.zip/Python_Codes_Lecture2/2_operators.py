# Operators used are : Subtraction, Multiplication, Addition and
# an exponentiation operator, the double star/asterisk ( ** )
print (-2 * 4 + 3 ** 2)

# Standard Comparision Operators are:
print (2 < 4)
print (2 == 4)
print (6.2 <= 6)

# Expression Conjunction operators are:
print ((2 < 4) and (2 == 4))
print ((2 > 4) or (2 < 4))
print (not (6.2 <= 6))