#Demonstrate the Module
import sys


#Calling variable of a module
print(sys.platform)
print(sys.version)
print ('I am running Python %s on %s' % (sys.version, sys.platform))
