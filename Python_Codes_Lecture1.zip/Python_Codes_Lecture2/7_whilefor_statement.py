#Demonstration of While statement
counter = 0
while counter < 5:
    print('loop #%d' % (counter))
    counter = counter + 1

#Demonstration of for statement
# print ('I like to use the Internet for:')
# for item in ['e-mail', 'net-surfing', 'homework', 'chat']:
#     print (item)

# for eachNum in range(6):
#     print (eachNum)
